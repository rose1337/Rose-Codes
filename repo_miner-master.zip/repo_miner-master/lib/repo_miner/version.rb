module RepoMiner
  VERSION = "0.3.1"
end
