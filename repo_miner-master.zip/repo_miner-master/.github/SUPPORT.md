# Libraries.io Support

If you're looking for support for Libraries.io there are a lot of options, check out:

* Documentation &mdash; https://docs.libraries.io
* Email &mdash; support@libraries.io
* Twitter &mdash; https://twitter.com/librariesio
* Chat &mdash; https://slack.libraries.io

On Discuss and in the Libraries.io Slack team, there are a bunch of helpful community members that should be willing to point you in the right direction.
