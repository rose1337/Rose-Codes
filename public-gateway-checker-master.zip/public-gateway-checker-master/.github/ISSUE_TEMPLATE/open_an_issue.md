---
name: Open an issue
about: Only for actionable issues relevant to this repository.
title: ''
labels: need/triage
assignees: ''

---
<!--
Hello! To ensure this issue is correctly addressed as soon as possible by the IPFS team, please try to make sure:

- This issue is relevant to this repository's topic or codebase.

- A clear description is provided. It should includes as much relevant information as possible and clear scope for the issue to be actionable.

FOR GENERAL DISCUSSION, HELP OR QUESTIONS, please see the options at https://ipfs.io/help or head directly to https://discuss.ipfs.io.

(you can delete this section after reading)
-->
