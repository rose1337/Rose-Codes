#! /usr/bin/env bash

ipfs add -wQ styles.css app.js index.html gateways.json > lastpubver
