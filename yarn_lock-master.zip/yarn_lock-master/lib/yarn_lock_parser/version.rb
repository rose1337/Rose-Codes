# frozen_string_literal: true

module YarnLockParser
  VERSION = '0.1.0'
end
