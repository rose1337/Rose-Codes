---
title: Bans FAQ
weight: 845
---

Global Bans
-----------
Our anticheat system is a robust trip-wire style system in which is automated in nature. The system detects the use of external of programs in which attempt to inject themselves into the FiveM client. The message will display upon the attempt to join a server and will indicate that you are Globally Banned as well as a timer in which displays the time remaining on your ban.
- **Important**: Graphic and sound packs or modifications **do not cause global bans.**

<br/>

Why does my ban have no timer nor does it say I'm globally banned?
------------------------------------------------------------------
There is one alternate message you may receive which indicates that you need to wait out your original ban. This occurs when an individual attempts to circumvent their orignal ban in various forms, therefore it is important to simply wait out your ban, if you're unsure how long - check if you can connect to a server every 3 - 5 days.

<br/>

Why aren't cheaters banned instantly?
-------------------------------------
Our anti-cheat relies on a checks and balances system which means that there are a series of checks and balances in place that with a userbase of over 100,000 players, it takes a little bit of time to perform to ensure accuracy.

<br/>

False Bans
----------
The anticheat system has been vigorously tested to ensure that there is an incredibly limited amount of false positives. So what do you do if you think that your ban is a mistake? Take a look
at the files you have been running in conjunction with the FiveM client.

<br/>

Unauthorized Game Server Provider (GSP)
---------------------------------------
There are situations where you may attempt to join a server and come accross a message indicating that the server you're attempting to join is blocked due to it not being an authorized Game Server Provider (GSP). Based on our [Terms of Service](https://fivem.net/terms) you can see that the only GSP allowed to be used and advertise itself for FiveM is ZAP Hosting.
While that is our only authorized Game Server Provider, you're welcome to use **any** Virtual Private Server of your choice as long as you have root access to the server itself. 

<br/>

I found cheats that are undetected! Get em!
-------------------------------------------
Whoa! That's unfortunate, are you sure they still are undetected? Our anticheat system bans are typically slighly delayed, within 24hrs after detection the user is banned. With that being said,
we cannot stay on top of them completely without your help, our community is our backbone. If you come across cheats in which you feel are undetected and you have the actual files, please feel free to send
them to [abuse@fivem.net](mailto:abuse@fivem.net). Additionally, take a look at [this link](https://docs.fivem.net/docs/support/resource-faq/#what-can-i-do-against-cheaters) to see what you can do to help 
fight against cheaters who may be affecting your server.
