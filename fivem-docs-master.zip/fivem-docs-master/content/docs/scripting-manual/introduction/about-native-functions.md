---
title: About native functions
weight: 413
---

This article is under development.
The full list of native functions can be found [here][natives-doc].


<!-- TODO:
Native functions, or just 'natives', are functions that do fucking shit wtf how do i possibly explain this

In FiveM, you have access to what is called 'native functions'. These functions interact with the game, and only work on
the client. It's a huge list. Very huge. The biggest you've ever seen. And it's great. To understand them you must have
a very high IQ, like me.

- Explain what natives are
- Where can you find them
- How to use them
-->

[natives-doc]: https://runtime.fivem.net/doc/reference.html
