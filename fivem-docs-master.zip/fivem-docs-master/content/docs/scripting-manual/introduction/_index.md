---
title: Scripting introduction
weight: 410
layout: single
---

- [Introduction to resources](/docs/scripting-manual/introduction/introduction-to-resources)
- [Creating your first script in Lua](/docs/scripting-manual/introduction/creating-your-first-script)
- [Creating your first script in C#](/docs/scripting-manual/introduction/creating-your-first-script-csharp)
- [Creating your first script in JavaScript](/docs/scripting-manual/introduction/creating-your-first-script-javascript)
- [About native functions](/docs/scripting-manual/introduction/about-native-functions)
