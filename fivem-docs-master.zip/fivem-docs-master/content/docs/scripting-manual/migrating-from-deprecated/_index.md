---
title: Migrating from deprecated methods
weight: 430
---

In the past few years, FiveM has developed and advanced vastly. As a result of this, many tutorials and scripts have been left behind with methods and whatnot. This section will provide instructions on how to change from methods that have been deprecated.

- [Chat Messages](/docs/scripting-manual/migrating-from-deprecated/chat-messages)
- [Creating Commands](/docs/scripting-manual/migrating-from-deprecated/creating-commands)
  