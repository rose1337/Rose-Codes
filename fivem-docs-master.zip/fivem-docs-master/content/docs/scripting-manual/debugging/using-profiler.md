---
title: Using the profiler
description: A guide to using the built-in resource profiler.
---

{{%  forum_topic "809058"  %}}