---
title: Server manual
weight: 300
---

Instructions on running and maintaining a server.
