---
title: Where to buy GTA V
weight: 210
---

FiveM requires a fully updated installation of GTA V. If you do not own a legal copy of GTA V yet, you can buy it from
any of the stores below. Of course you can also buy the game from your preferred local retailer, these are just the most
common ones.

FiveM does not condone the use of pirated software and **will not work** with illegitimate versions of GTA V. Respect
the authors, buy the game.

- [Steam](https://store.steampowered.com/app/271590/Grand_Theft_Auto_V/)
- [Epic Games Store](https://www.epicgames.com/store/product/grand-theft-auto-v)
- [Rockstar Warehouse](https://store.rockstargames.com/en/game/buy-gta-v-premium-edition)
- [Amazon](https://www.amazon.com/Grand-Theft-Auto-V-PC/dp/B00KVXB5YQ)
- [Newegg](https://www.newegg.com/rockstar-games-grand-theft-auto-v-with-gta-online-pc/p/N82E16832137064)

