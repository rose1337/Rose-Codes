---
title: Coding guidelines
draft: true
---

TODO
