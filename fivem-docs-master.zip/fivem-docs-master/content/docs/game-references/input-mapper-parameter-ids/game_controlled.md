---
title: GAME_CONTROLLED
weight: 716
---

Vaild parameters for this mapper are unknown.

This is presumably an input source for input being forced / controlled by the game. More testing is needed to confirm this.
