---
title: TOUCHPAD_CENTERED_AXIS
weight: 716
---

Vaild parameters for this mapper are unknown.

This is presumably an input source for the PS4/5 controller touchpad.
