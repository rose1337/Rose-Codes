---
title: JOYSTICK_POV_AXIS
weight: 716
---

| Input Parameter  | Input Description    |
| ---------------- | -------------------- |
| IOM\_POV1\_UP    | *hardware dependent* |
| IOM\_POV1\_RIGHT | *hardware dependent* |
| IOM\_POV1\_DOWN  | *hardware dependent* |
| IOM\_POV1\_LEFT  | *hardware dependent* |
| IOM\_POV2\_UP    | *hardware dependent* |
| IOM\_POV2\_RIGHT | *hardware dependent* |
| IOM\_POV2\_DOWN  | *hardware dependent* |
| IOM\_POV2\_LEFT  | *hardware dependent* |
| IOM\_POV3\_UP    | *hardware dependent* |
| IOM\_POV3\_RIGHT | *hardware dependent* |
| IOM\_POV3\_DOWN  | *hardware dependent* |
| IOM\_POV3\_LEFT  | *hardware dependent* |
| IOM\_POV4\_UP    | *hardware dependent* |
| IOM\_POV4\_RIGHT | *hardware dependent* |
| IOM\_POV4\_DOWN  | *hardware dependent* |
| IOM\_POV4\_LEFT  | *hardware dependent* |
