---
title: MOUSE_WHEEL
weight: 716
---

| Input Parameter             | Input Description |
| --------------------------- | ----------------- |
| IOM\_WHEEL\_UP              | Mouse Wheel Up    |
| IOM\_WHEEL\_DOWN            | Mouse Wheel Down  |
