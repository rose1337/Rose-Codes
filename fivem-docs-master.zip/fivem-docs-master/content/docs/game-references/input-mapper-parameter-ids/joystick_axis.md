---
title: JOYSTICK_AXIS
weight: 716
---

| Input Parameter    | Input Description    |
| ------------------ | -------------------- |
| IOM_JOYSTICK_AXIS1 | *hardware dependent* |
| IOM_JOYSTICK_AXIS2 | *hardware dependent* |
| IOM_JOYSTICK_AXIS3 | *hardware dependent* |
| IOM_JOYSTICK_AXIS4 | *hardware dependent* |
| IOM_JOYSTICK_AXIS5 | *hardware dependent* |
| IOM_JOYSTICK_AXIS6 | *hardware dependent* |
| IOM_JOYSTICK_AXIS7 | *hardware dependent* |
| IOM_JOYSTICK_AXIS8 | *hardware dependent* |
