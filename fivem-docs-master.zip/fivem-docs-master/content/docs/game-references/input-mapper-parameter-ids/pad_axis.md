---
title: PAD_AXIS
weight: 716
---

| Input Parameter   | Input Description |
| ----------------- | ----------------- |
| IOM_AXIS_LX       | *unknown*         |
| IOM_AXIS_LY       | *unknown*         |
| IOM_AXIS_RX       | *unknown*         |
| IOM_AXIS_RY       | *unknown*         |
| IOM_AXIS_LUP      | *unknown*         |
| IOM_AXIS_LDOWN    | *unknown*         |
| IOM_AXIS_LLEFT    | *unknown*         |
| IOM_AXIS_LRIGHT   | *unknown*         |
| IOM_AXIS_LUR      | *unknown*         |
| IOM_AXIS_LUL      | *unknown*         |
| IOM_AXIS_LDR      | *unknown*         |
| IOM_AXIS_LDL      | *unknown*         |
| IOM_AXIS_RUP      | *unknown*         |
| IOM_AXIS_RDOWN    | *unknown*         |
| IOM_AXIS_RLEFT    | *unknown*         |
| IOM_AXIS_RRIGHT   | *unknown*         |
| IOM_AXIS_RUR      | *unknown*         |
| IOM_AXIS_RUL      | *unknown*         |
| IOM_AXIS_RDR      | *unknown*         |
| IOM_AXIS_RDL      | *unknown*         |
| IOM_AXIS_DPADX    | *unknown*         |
| IOM_AXIS_DPADY    | *unknown*         |
| IOM_AXIS_LY_UP    | *unknown*         |
| IOM_AXIS_LY_DOWN  | *unknown*         |
| IOM_AXIS_LX_LEFT  | *unknown*         |
| IOM_AXIS_LX_RIGHT | *unknown*         |
| IOM_AXIS_RY_UP    | *unknown*         |
| IOM_AXIS_RY_DOWN  | *unknown*         |
| IOM_AXIS_RX_LEFT  | *unknown*         |
| IOM_AXIS_RX_RIGHT | *unknown*         |
