---
title: JOYSTICK_BUTTON
weight: 716
---

| Input Parameter         | Input Description    |
| ----------------------- | -------------------- |
| IOM\_JOYSTICK\_BUTTON1  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON2  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON3  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON4  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON5  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON6  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON7  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON8  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON9  | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON10 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON11 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON12 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON13 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON14 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON15 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON16 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON17 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON18 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON19 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON20 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON21 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON22 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON23 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON24 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON25 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON26 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON27 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON28 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON29 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON30 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON31 | *hardware dependent* |
| IOM\_JOYSTICK\_BUTTON32 | *hardware dependent* |
