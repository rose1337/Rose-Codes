---
title: MOUSE_BUTTON
weight: 716
---

| Input Parameter             | Input Description             |
| --------------------------- | ----------------------------- |
| MOUSE\_LEFT                 | Mouse Button 0 (Left Click)   |
| MOUSE\_RIGHT                | Mouse Button 1 (Right Click)  |
| MOUSE\_MIDDLE               | Mouse Button 2 (Middle Click) |
| MOUSE\_EXTRABTN1            | Mouse Button 3                |
| MOUSE\_EXTRABTN2            | Mouse Button 4                |
| MOUSE\_EXTRABTN3            | Mouse Button 5                |
| MOUSE\_EXTRABTN4            | Mouse Button 6                |
| MOUSE\_EXTRABTN5            | Mouse Button 7                |
| IOM\_WHEEL\_UP              | Mouse Wheel Up                |
| IOM\_WHEEL\_DOWN            | Mouse Wheel Down              |
