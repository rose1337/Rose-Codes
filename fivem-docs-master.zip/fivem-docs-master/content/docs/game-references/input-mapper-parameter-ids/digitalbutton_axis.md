---
title: DIGITALBUTTON_AXIS
weight: 716
---

Vaild parameters for this mapper are unknown.

This is presumably an input mapper for axis input from digital controller buttons.
