---
title: C# function reference
weight: 507
hidden: false
layout: single
---

- [Client side functions](/docs/scripting-reference/runtimes/csharp/client-functions)
- [Server side functions](/docs/scripting-reference/runtimes/csharp/server-functions)