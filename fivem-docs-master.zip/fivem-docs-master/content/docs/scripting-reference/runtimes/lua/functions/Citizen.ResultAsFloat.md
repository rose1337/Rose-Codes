---
title: Citizen.ResultAsFloat
---

Syntax
------

```lua
-- todo
```