---
title: Citizen.ResultAsLong
---

Syntax
------

```lua
-- todo
```