---
title: Citizen.CanonicalizeRef
---

Syntax
------

```lua
-- todo
```