---
title: Citizen.SetEventRoutine
---

Syntax
------

```lua
-- todo
```