---
title: Citizen.InvokeFunctionReference
---

Syntax
------

```lua
-- todo
```