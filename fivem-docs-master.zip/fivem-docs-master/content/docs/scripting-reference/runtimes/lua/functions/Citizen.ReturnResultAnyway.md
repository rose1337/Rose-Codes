---
title: Citizen.ReturnResultAnyway
---

Syntax
------

```lua
-- todo
```