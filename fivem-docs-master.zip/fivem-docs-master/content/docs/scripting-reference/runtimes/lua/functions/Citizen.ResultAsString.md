---
title: Citizen.ResultAsString
---

Syntax
------

```lua
-- todo
```