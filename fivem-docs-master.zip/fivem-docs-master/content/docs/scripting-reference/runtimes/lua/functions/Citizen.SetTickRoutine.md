---
title: Citizen.SetTickRoutine
---

Syntax
------

```lua
-- todo
```