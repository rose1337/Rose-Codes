---
title: Citizen.PointerValueIntInitialized
---

Syntax
------

```lua
-- todo
```