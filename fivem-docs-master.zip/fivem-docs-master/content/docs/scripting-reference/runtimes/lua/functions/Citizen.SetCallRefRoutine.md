---
title: Citizen.SetCallRefRoutine
---

Syntax
------

```lua
-- todo
```