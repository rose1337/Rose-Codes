---
title: Citizen.ResultAsInteger
---

Syntax
------

```lua
-- todo
```