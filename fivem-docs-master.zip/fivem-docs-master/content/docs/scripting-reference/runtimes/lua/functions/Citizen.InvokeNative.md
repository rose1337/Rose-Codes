---
title: Citizen.InvokeNative
---

Syntax
------

```lua
-- todo
```