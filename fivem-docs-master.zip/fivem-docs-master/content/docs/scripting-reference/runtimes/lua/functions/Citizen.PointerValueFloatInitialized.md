---
title: Citizen.PointerValueFloatInitialized
---

Syntax
------

```lua
-- todo
```