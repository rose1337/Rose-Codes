---
title: Citizen.GetFunctionReference
---

Syntax
------

```lua
-- todo
```