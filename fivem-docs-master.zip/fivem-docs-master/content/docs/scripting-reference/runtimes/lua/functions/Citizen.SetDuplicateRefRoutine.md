---
title: Citizen.SetDuplicateRefRoutine
---

Syntax
------

```lua
-- todo
```