---
title: Citizen.PointerValueVector
---

Syntax
------

```lua
-- todo
```