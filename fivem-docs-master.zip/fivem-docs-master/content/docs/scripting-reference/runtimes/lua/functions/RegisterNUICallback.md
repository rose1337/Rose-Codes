---
title: RegisterNUICallback
---

Syntax
------

```lua
-- todo
```