---
title: Citizen.ResultAsObject
---

Syntax
------

```lua
-- todo
```