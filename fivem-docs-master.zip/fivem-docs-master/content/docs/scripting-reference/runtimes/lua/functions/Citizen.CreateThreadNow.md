---
title: Citizen.CreateThreadNow
---

Syntax
------

```lua
-- todo
```