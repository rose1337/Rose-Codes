---
title: Citizen.ResultAsVector
---

Syntax
------

```lua
-- todo
```