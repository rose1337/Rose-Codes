---
title: Citizen.PointerValueFloat
---

Syntax
------

```lua
-- todo
```