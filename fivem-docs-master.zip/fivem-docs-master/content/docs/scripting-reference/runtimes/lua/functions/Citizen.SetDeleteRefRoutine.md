---
title: Citizen.SetDeleteRefRoutine
---

Syntax
------

```lua
-- todo
```