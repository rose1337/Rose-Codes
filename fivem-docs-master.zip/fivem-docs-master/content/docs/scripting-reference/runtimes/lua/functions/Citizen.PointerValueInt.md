---
title: Citizen.PointerValueInt
---

Syntax
------

```lua
-- todo
```