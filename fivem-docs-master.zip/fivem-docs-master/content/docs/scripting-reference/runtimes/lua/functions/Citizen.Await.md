---
title: Citizen.Await
---

Syntax
------

```lua
Citizen.Await(awaitable)
```