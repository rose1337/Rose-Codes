---
title: Lua function reference
weight: 513
hidden: false
layout: single
---

- [Client side functions](/docs/scripting-reference/runtimes/lua/client-functions)
- [Server side functions](/docs/scripting-reference/runtimes/lua/server-functions)