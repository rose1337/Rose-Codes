---
title: Runtime-specific references
weight: 506
layout: single
---

- [Functions in Lua](/docs/scripting-reference/runtimes/lua)
- [Functions in JavaScript](/docs/scripting-reference/runtimes/javascript)
- [Functions in C#](/docs/scripting-reference/runtimes/csharp)
