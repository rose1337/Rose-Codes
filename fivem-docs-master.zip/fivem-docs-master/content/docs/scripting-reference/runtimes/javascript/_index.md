---
title: JavaScript function reference
weight: 510
hidden: false
layout: single
---

- [Client side functions](/docs/scripting-reference/runtimes/javascript/client-functions)
- [Server side functions](/docs/scripting-reference/runtimes/javascript/server-functions)