---
title: Events
weight: 540
hidden: false
---

- [Client events](/docs/scripting-reference/events/client-events/)
- [Server events](/docs/scripting-reference/events/server-events/)
- [List of events](/docs/scripting-reference/events/list/)
