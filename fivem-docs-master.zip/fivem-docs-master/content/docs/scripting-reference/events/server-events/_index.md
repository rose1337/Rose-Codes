---
title: Server events
weight: 542
layout: single
---

**A list of server side events you can use in your scripts.**

Core events
-----------

These events are part of FiveM and do not require any resource.

{{% events "server" %}}