---
title: Scripting reference
weight: 500
layout: single
---

- [Resource manifest](/docs/scripting-reference/resource-manifest/resource-manifest)
- [Native functions](https://docs.fivem.net/natives/)
- [Client functions](/docs/scripting-reference/client-functions)
- [Server functions](/docs/scripting-reference/server-functions)
<!-- TODO: - [Useful functions](/docs/scripting-reference/useful-functions)-->
- [Client events](/docs/scripting-reference/events/client-events)
- [Server events](/docs/scripting-reference/events/server-events)
- [Convars](/docs/scripting-reference/convars)
- [OneSync](/docs/scripting-reference/onesync)