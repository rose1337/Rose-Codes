---
title: chat:addSuggestions
---

## About
Triggering this event allows you to add multiple command suggestions to your chat using a single event.

## Name
```
chat:addSuggestions
```


Parameters
----------

```
array suggestions
```

- **suggestions**: an array containing multiple [suggestion](../chat-addSuggestion) objects.

Examples
--------

TODO