---
title: Events
---

## Events

### Client
- [chatMessage](./chatMessage) (deprecated, use chat:addMessage instead)
- [chat:addMessage](./chat-addMessage)
- [chat:addSuggestion](./chat-addSuggestion)
- [chat:addSuggestions](./chat-addSuggestions)
- [chat:removeSuggestion](./chat-removeSuggestion)
- [chat:addTemplate](./chat-addTemplate)
- [chat:clear](./chat-clear)

### Server
- [chatMessage](./chatMessage)