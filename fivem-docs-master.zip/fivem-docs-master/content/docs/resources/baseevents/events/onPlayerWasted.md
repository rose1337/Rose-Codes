---
title: onPlayerWasted
---

Name
----------
```
baseevents:onPlayerWasted
```


Parameters
----------

```
array deathCoords
```

- **deathCoords**: A table containing the x, y and z coordinates of where the (source) player died.

Examples
--------

TODO
