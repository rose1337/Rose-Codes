---
title: enteringAborted
---

Name
----------
```
baseevents:enteringAborted
```

Parameters
----------

_There are no parameters for this event._


Examples
--------

TODO
