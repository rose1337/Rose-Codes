---
title: Resource Template
toc_hide: true
draft: true
---

## About
Basic description about this resource.

## Exports

### Client
- links
- to

### Server
- exports
- (if any)

## Events

### Client
- links
- to

### Server
- events
- (if any)