---
title: sessionInitialized
---

Parameters
----------

TODO

Examples
--------

TODO
