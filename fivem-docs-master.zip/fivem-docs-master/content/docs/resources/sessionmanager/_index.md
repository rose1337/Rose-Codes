---
title: sessionmanager
---

##### TODO

<!--
## About
_Todo._

## Exports

### Client
- todo

### Server
- todo

## Events

### Client
- todo

### Server
- todo
-->