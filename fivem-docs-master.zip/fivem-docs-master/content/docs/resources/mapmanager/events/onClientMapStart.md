---
title: onClientMapStart
---

Parameters
----------

```
string resourceName
```

- **resourceName**:  The name of the resource/map that started.

Examples
--------

TODO
