---
title: onClientGameTypeStart
---

Parameters
----------

```
string resourceName
```

- **resourceName**: The name of the resource/gametype that started.

Examples
--------

TODO
