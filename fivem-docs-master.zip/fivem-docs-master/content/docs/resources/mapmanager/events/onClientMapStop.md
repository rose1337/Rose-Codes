---
title: onClientMapStop
---

Parameters
----------

```
string resourceName
```

- **resourceName**:  The name of the resource/map that stopped.

Examples
--------

TODO
