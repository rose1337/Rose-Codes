---
title: onClientGameTypeStop
---

Parameters
----------

```
string resourceName
```

- **resourceName**: The name of the resource/gametype that stopped.

Examples
--------

TODO
