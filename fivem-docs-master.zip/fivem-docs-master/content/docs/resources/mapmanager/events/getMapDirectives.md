---
title: getMapDirectives
---

Parameters
----------

```
function add
```

- **add**: A function used to add a specific map directive.

Examples
--------

TODO
